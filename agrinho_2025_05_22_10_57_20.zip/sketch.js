let agrinho;
let sementes = [];
let score = 0;

function setup() {
  createCanvas(600, 400);
  agrinho = new Agrinho();
  for (let i = 0; i < 10; i++) {
    sementes.push(createSemente());
  }
}

function draw() {
  background(100, 200, 100); // Cor do fundo (campo)
  
  // Exibir e mover o agrinho
  agrinho.show();
  agrinho.move();

  // Exibir sementes
  for (let i = sementes.length - 1; i >= 0; i--) {
    sementes[i].show();
    if (agrinho.collect(sementes[i])) {
      sementes.splice(i, 1); // Remover a semente do array
      score++;
      sementes.push(createSemente()); // Criar uma nova semente
    }
  }

  // Exibir o score
  textSize(24);
  fill(0);
  text('Sementes coletadas: ' + score, 10, 30);
}

function createSemente() {
  return new Semente(random(width), random(height));
}

// Classe do Agrinho
class Agrinho {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.size = 30; // Tamanho inicial
    this.speed = 5;
  }

  show() {
    fill(255, 204, 0); // Cor do agrinho (amarelo)
    ellipse(this.x, this.y, this.size, this.size); // Representa o agrinho como um círculo
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
  }

  collect(semente) {
    let d = dist(this.x, this.y, semente.x, semente.y);
    if (d < this.size / 2 + semente.size / 2) {
      this.size += 5; // Aumenta o tamanho do agrinho ao coletar uma semente
      return true;
    }
    return false;
  }
}

// Classe da Semente
class Semente {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10;
  }

  show() {
    fill(255, 100, 100); // Cor da semente (vermelha)
    ellipse(this.x, this.y, this.size, this.size);
  }
}
